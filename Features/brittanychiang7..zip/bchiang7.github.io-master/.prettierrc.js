module.exports = require('@nuscout/prettier-config');
